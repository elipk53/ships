import OneCategory from "./OneCategory";

export default OneCategory;
