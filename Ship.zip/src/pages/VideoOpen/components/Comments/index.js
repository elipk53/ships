import Comments from "./Comments";

export default Comments;
