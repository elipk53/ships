import CommentBox from "./CommentBox";

export default CommentBox;
