import PersonalInfo from "./PersonalInfo";

export default PersonalInfo;
