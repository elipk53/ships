import ForumProfile from "./ForumProfile";

export default ForumProfile;
