import Preferences from "./Preferences";

export default Preferences;
