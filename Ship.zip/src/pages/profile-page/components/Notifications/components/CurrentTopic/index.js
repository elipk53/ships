import CurrentTopic from "./CurrentTopic";

export default CurrentTopic;
