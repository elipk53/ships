import General from "./General";

export default General;
