import CurrentTopicTwo from "./CurrentTopicTwo";

export default CurrentTopicTwo;
