import AISFooter from "./AISFooter";

export default AISFooter;
