import AISHeader from "./AISHeader";

export default AISHeader;
