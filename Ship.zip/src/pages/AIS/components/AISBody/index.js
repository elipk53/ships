import AISBody from "./AISBody";

export default AISBody;
