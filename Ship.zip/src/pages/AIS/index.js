import AIS from "./AIS";

export default AIS;
