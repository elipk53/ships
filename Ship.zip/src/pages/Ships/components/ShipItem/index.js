import ShipItem from "./ShipItem";

export default ShipItem;
