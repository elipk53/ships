import Ships from "./Ships";

export default Ships;
