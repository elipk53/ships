import AnchorContent from "./AnchorContent";

export default AnchorContent;
