import HeaderTabs from "./HeaderTabs";

export default HeaderTabs;
