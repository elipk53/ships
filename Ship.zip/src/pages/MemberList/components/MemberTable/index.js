import MemberTable from "./MemberTable";

export default MemberTable;
