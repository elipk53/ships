import Forums from "./Forums";

export default Forums;
