import TopicCard from "./TopicCard";

export default TopicCard;
