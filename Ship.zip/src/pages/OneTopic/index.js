import OneTopic from "./OneTopic";

export default OneTopic;
