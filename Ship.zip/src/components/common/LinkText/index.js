import LinkText from "./LinkText";

export default LinkText;
