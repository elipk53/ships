export const ships = [
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
  {
    url:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS_OOv8kFrm304MrhCgJsYutlNuG1Zr3o751g&usqp=CAU",
    photographer: "MYSTERY VESSEL",
    shipName: "Anthony Legg",
  },
];
